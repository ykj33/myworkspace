package share;

public class FrontController {

}
