package share;

public interface Command {

}
