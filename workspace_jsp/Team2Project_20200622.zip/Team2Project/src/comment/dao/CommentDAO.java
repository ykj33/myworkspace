package comment.dao;

public class CommentDAO {

}
